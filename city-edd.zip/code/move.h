#ifndef _MOVE_H_
#define _MOVE_H_

void move_step();

#endif
