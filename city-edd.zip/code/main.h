#ifndef _MAIN_H_
#define _MAIN_H_

extern int CITIES;

extern float theta;

extern int floadcities;

extern int tempviz[CITIESMAX][CITIESMAX];

#endif
