#ifndef _DEFS_H_
#define _DEFS_H_

#define CITIESMAX	30

#define ITER	100
#define E 2.718281828459045

//#define _DEBUG_

#endif
